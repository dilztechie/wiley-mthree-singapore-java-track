import org.wiley.sms.bean.Student;

public class StudentDetails {
	public static void main(String[] args) {
		System.out.println("Inside main");
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			
			java.sql.Connection connection = 
					java.sql.DriverManager.getConnection(
							"jdbc:oracle:thin:@localhost:1521:xe", 
							"raveena", 
							"hellow");
			
			java.sql.Statement statement = connection.createStatement();
			
			java.sql.ResultSet results = statement.executeQuery("SELECT * FROM Student");
			
			while(results.next()) {
				long id = results.getLong("id");
				String name = results.getString("name");
				int mark1 = results.getInt("mark1");
				int mark2 = results.getInt("mark2");
				int mark3 = results.getInt("mark3");
				
			}
			
			connection.close();
			
		} catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
 		} catch(java.sql.SQLException sqle) {
			sqle.printStackTrace();
		}
	}
}
