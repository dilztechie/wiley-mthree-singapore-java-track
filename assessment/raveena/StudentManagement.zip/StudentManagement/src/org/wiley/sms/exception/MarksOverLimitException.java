package org.wiley.sms.exception;

@SuppressWarnings("serial")
public class MarksOverLimitException extends Exception {
	public MarksOverLimitException(String message) {
		super(message);
	}
}
