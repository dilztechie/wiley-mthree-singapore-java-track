package org.wiley.sms.service;

public interface StudentServiceIntf {
	
	public long addStudent(String name, int mark1, int mark2, int mark3) throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.MarksOverLimitException;

	public java.util.Map<Long, org.wiley.sms.bean.Student> getAllStudents() throws ClassNotFoundException, java.sql.SQLException;
	
	public org.wiley.sms.bean.Student getStudentById(long id) throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.StudentNotFoundException;
	
	public org.wiley.sms.bean.Student updateStudentMarks(long id, org.wiley.sms.bean.Student student) throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.StudentNotFoundException;
	
	public boolean deleteStudent(long id) throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.StudentNotFoundException;
}
