package org.wiley.sms.service;

public class StudentServiceImpl implements StudentServiceIntf {
	
	@Override
	public long addStudent(String name, int mark1, int mark2, int mark3) throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.MarksOverLimitException {
		java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
		java.sql.Statement statement = connection.createStatement();
		java.sql.ResultSet result = statement.executeQuery("SELECT MAX(id) FROM Student");
		long newId = 1;
		if(result.next()) {
			newId = 1 + result.getInt(1);
		}
		
		String sql = "INSERT INTO Student VALUES (?, ?, ?, ?, ?)";
		java.sql.PreparedStatement prepareStatement = connection.prepareStatement(sql);
		
		prepareStatement.setLong(1, newId);
		prepareStatement.setString(2, name);
		prepareStatement.setInt(3, mark1);
		prepareStatement.setInt(4, mark2);
		prepareStatement.setInt(5, mark3);
		if(mark1>100 || mark2>100 || mark3>100) {
			throw new org.wiley.sms.exception.MarksOverLimitException("Marks are not valid. Please re-enter.");
		}
		
		prepareStatement.execute();
	
		if(!connection.getAutoCommit()) {
			connection.commit();
		}
		connection.close();
		return newId;
	}
	
	
	@Override
	public java.util.Map<Long, org.wiley.sms.bean.Student> getAllStudents() throws ClassNotFoundException, java.sql.SQLException {
		java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
		java.sql.Statement statement = connection.createStatement();
		java.sql.ResultSet results = statement.executeQuery("SELECT * FROM Student");
		java.util.Map<Long, org.wiley.sms.bean.Student> students = new java.util.TreeMap<>();
		while(results.next()) {
			long id = results.getLong("id");
			String name = results.getString("name");
			int mark1 = results.getInt("mark1");
			int mark2 = results.getInt("mark2");
			int mark3 = results.getInt("mark3");
			org.wiley.sms.bean.Student student = new org.wiley.sms.bean.Student(id, name, mark1, mark2, mark3);
			students.put(student.getId(), student);
		}
		return students;
	}
	
	@Override
	public org.wiley.sms.bean.Student getStudentById(long id) throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.StudentNotFoundException {
		java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
		String sql = "SELECT * FROM Student WHERE id = ?";
		java.sql.PreparedStatement statement = connection.prepareStatement(sql);
		statement.setLong(1, id);
		java.sql.ResultSet result = statement.executeQuery();
		org.wiley.sms.bean.Student student;
		if(result.next()) {
			String name = result.getString("name");
			int mark1 = result.getInt("mark1");
			int mark2 = result.getInt("mark2");
			int mark3 = result.getInt("mark3");
			student = new org.wiley.sms.bean.Student(id, name, mark1, mark2, mark3);
			
		} else {
			throw new org.wiley.sms.exception.StudentNotFoundException("Student with id " + id + " not found");
		}
		connection.close();
		return student;
	}
	
	
	@Override
	public org.wiley.sms.bean.Student updateStudentMarks(long id, org.wiley.sms.bean.Student student) throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.StudentNotFoundException {
		
		getStudentById(id);
		java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
		String sql = "UPDATE StudentMarks SET mark1 = ?, mark2 = ?, mark3 = ? WHERE id = ?";
		java.sql.PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, student.getMark1());
		statement.setInt(2, student.getMark2());
		statement.setInt(3, student.getMark3());
		statement.setLong(4, id);
		statement.execute();
		if(!connection.getAutoCommit()) {
			connection.commit();
		}
		connection.close();
		org.wiley.sms.bean.Student updatedStudent = getStudentById(id);
		return updatedStudent;
	}
	
	
	@Override
	public boolean deleteStudent(long id) throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.StudentNotFoundException {
		getStudentById(id);
		java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
		String sql = "DELETE FROM Student WHERE id = ?";
		java.sql.PreparedStatement statement = connection.prepareStatement(sql);
		statement.setLong(1, id);
		statement.execute();
		if(!connection.getAutoCommit()) {
			connection.commit();
		}
		connection.close();
		return true;
	}

}
