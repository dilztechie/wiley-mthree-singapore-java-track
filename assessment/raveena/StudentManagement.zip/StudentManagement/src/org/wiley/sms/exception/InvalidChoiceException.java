package org.wiley.sms.exception;

@SuppressWarnings("serial")
public class InvalidChoiceException extends Exception {
	public InvalidChoiceException(String message) {
		super(message);
	}
}
