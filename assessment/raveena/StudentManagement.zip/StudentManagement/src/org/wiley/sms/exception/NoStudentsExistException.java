package org.wiley.sms.exception;

@SuppressWarnings("serial")
public class NoStudentsExistException extends Exception {
	public NoStudentsExistException(String message) {
		super(message);
	}

}
