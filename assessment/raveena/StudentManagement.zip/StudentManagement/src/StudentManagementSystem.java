
public class StudentManagementSystem {
static java.util.Scanner in = new java.util.Scanner(System.in);
	
	static org.wiley.sms.service.StudentServiceIntf studentService = new org.wiley.sms.service.StudentServiceImpl();
	
	public static void main(String[] args) {
		int choice = 0;
		do {
			sop("\n");
			try {
				menu();
				choice = in.nextInt();
				switch(choice) {
					case 1: addStudent();			break;
					case 2: getAllStudents();		break;
					case 3: getStudentById();		break;
					case 4: updateStudentMarks();	break;
					case 5: deleteStudent();		break;
					case 0: break;
					default: throw new org.wiley.sms.exception.InvalidChoiceException("Invalid Choice! Try 1-5, 0: Exit");
				}
			} catch(org.wiley.sms.exception.InvalidChoiceException ice) {
				System.err.println(ice.getMessage());
			}
			sop("\n");
		} while(choice != 0);
	}
	
	static void menu() {
		sop("Student Management System\n");
		sop("-------------------------\n");
		sop("1. Add Students\n");
		sop("2. Get All Students and Details\n");
		sop("3. Get Student By ID\n");
		sop("4. Update Student Marks\n");
		sop("5. Delete Student\n");
		sop("0. Exit\n");
		sop("Choice? ");
	}
	
	static void sop(String text) {
		System.out.print(text);
	}
	
	static void addStudent() {
		try {
			sop("Name? ");
			if(in.hasNextLine() ) {
				in.nextLine();
			}
			String name = in.nextLine();
			sop("Subject1 marks? ");
			int mark1 = in.nextInt();
			sop("Subject2 marks? ");
			int mark2 = in.nextInt();
			sop("Subject3 marks? ");
			int mark3 = in.nextInt();
			sop("Employee added with id " + studentService.addStudent(name, mark1, mark2, mark3) + "\n");
		}  catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} catch(java.sql.SQLException sqle) {
			sqle.printStackTrace();
		} catch(org.wiley.sms.exception.MarksOverLimitException mol) {
			System.err.println(mol.getMessage());
		}
	}
	
	static void getAllStudents() {
		try {
			java.util.Map<Long, org.wiley.sms.bean.Student> students = studentService.getAllStudents();
			java.util.Set<Long> ids = students.keySet();
			if(ids.size() == 0 || ids == null) {
				throw new org.wiley.sms.exception.NoStudentsExistException("No Students in the Database");
			}
			for(long id : ids) {
				sop(students.get(id) + "\n");
			}
		} catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} catch(java.sql.SQLException sqle) {
			sqle.printStackTrace();
		} catch(org.wiley.sms.exception.NoStudentsExistException nsee) {
			System.err.println(nsee.getMessage());
		}
	}
	
	static void getStudentById() {
		try {
			sop("ID? ");
			long id = in.nextLong();
			sop(studentService.getStudentById(id) + "\n");
		} catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} catch(java.sql.SQLException sqle) {
			sqle.printStackTrace();
		} catch(org.wiley.sms.exception.StudentNotFoundException snfe) {
			System.err.println(snfe.getMessage());
		}
	}
	
	static void updateStudentMarks() {
		try {
			sop("ID? ");
			long id = in.nextLong();
			sop("Name? ");
			if(in.hasNextLine() ) {
				in.nextLine();
			}
			String name = in.nextLine();
			sop("Subject1? ");
			int mark1 = in.nextInt();
			sop("Subject2? ");
			int mark2 = in.nextInt();
			sop("Subject3? ");
			int mark3 = in.nextInt();
			org.wiley.sms.bean.Student student = new org.wiley.sms.bean.Student(id, name, mark1, mark2, mark3);
			sop("Updated Student: " + studentService.updateStudentMarks(id, student) + "\n");
		} catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} catch(java.sql.SQLException sqle) {
			sqle.printStackTrace();
		} catch(org.wiley.sms.exception.StudentNotFoundException snfe) {
			System.err.println(snfe.getMessage());
		}
	}
	
	
	static void deleteStudent() {
		try {
			sop("ID? ");
			long id = in.nextLong();
			if(studentService.deleteStudent(id)) {
				sop("Student with id " + id + " deleted\n");
			}
		} catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} catch(java.sql.SQLException sqle) {
			sqle.printStackTrace();
		} catch(org.wiley.sms.exception.StudentNotFoundException snfe) {
			System.err.println(snfe.getMessage());
		}
	}
	
	

}
