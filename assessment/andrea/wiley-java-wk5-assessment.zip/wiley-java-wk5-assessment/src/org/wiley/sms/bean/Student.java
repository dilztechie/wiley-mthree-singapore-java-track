package org.wiley.sms.bean;

public class Student {
    private long id;
    private String name;
    private String subject1;
    private int marks1;
    private String subject2;
    private int marks2;
    private String subject3;
    private int marks3;

    public Student(long id, String name, String subject1, int marks1, String subject2, int marks2, String subject3, int marks3) {
        this.id = id;
        this.name = name;
        this.subject1 = subject1;
        this.marks1 = marks1;
        this.subject2 = subject2;
        this.marks2 = marks2;
        this.subject3 = subject3;
        this.marks3 = marks3;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject1() {
        return subject1;
    }

    public void setSubject1(String subject1) {
        this.subject1 = subject1;
    }

    public int getMarks1() {
        return marks1;
    }

    public void setMarks1(int marks1) {
        this.marks1 = marks1;
    }

    public String getSubject2() {
        return subject2;
    }

    public void setSubject2(String subject2) {
        this.subject2 = subject2;
    }

    public int getMarks2() {
        return marks2;
    }

    public void setMarks2(int marks2) {
        this.marks2 = marks2;
    }

    public String getSubject3() {
        return subject3;
    }

    public void setSubject3(String subject3) {
        this.subject3 = subject3;
    }

    public int getMarks3() {
        return marks3;
    }

    public void setMarks3(int marks3) {
        this.marks3 = marks3;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", subject1='" + subject1 + '\'' +
                ", marks1=" + marks1 +
                ", subject2='" + subject2 + '\'' +
                ", marks2=" + marks2 +
                ", subject3='" + subject3 + '\'' +
                ", marks3=" + marks3 +
                '}';
    }
}
