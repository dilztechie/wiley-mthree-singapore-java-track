package org.wiley.sms.exception;

public class NoStudentsExistException extends Exception {
    public NoStudentsExistException(String message) {
        super(message);
    }
}
