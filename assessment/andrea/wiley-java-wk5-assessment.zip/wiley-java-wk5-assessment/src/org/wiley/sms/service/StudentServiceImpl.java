package org.wiley.sms.service;

import org.wiley.sms.bean.Student;
import org.wiley.sms.exception.StudentNotFoundException;

import java.sql.SQLException;
import java.util.Map;

public class StudentServiceImpl implements StudentServiceIntf {
    @Override
    public long addStudent(String name, String subject1, int marks1, String subject2, int marks2, String subject3, int marks3) throws ClassNotFoundException, SQLException {
        java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
        java.sql.Statement statement = connection.createStatement();
        java.sql.ResultSet result = statement.executeQuery("SELECT MAX(id) FROM Student");
        long newId = 1;
        if(result.next()) {
            newId = 1 + result.getInt(1);
        }
        String sql = "INSERT INTO Student VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        java.sql.PreparedStatement prepareStatement = connection.prepareStatement(sql);
        prepareStatement.setLong(1, newId);
        prepareStatement.setString(2, name);
        prepareStatement.setString(3, subject1);
        prepareStatement.setInt(4, marks1);
        prepareStatement.setString(5, subject2);
        prepareStatement.setInt(6, marks2);
        prepareStatement.setString(7, subject3);
        prepareStatement.setInt(8, marks3);
        prepareStatement.execute();
        if(!connection.getAutoCommit()) {
            connection.commit();
        }
        connection.close();
        return newId;
    }

    @Override
    public Map<Long, Student> getAllStudents() throws ClassNotFoundException, SQLException {
        java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
        java.sql.Statement statement = connection.createStatement();
        java.sql.ResultSet results = statement.executeQuery("SELECT * FROM Student");
        java.util.Map<Long, Student> students = new java.util.TreeMap<>();
        while(results.next()) {
            long id = results.getLong("id");
            String name = results.getString("name");
            String subject1 = results.getString("subject1");
            int marks1 = results.getInt("marks1");
            String subject2 = results.getString("subject2");
            int marks2 = results.getInt("marks2");
            String subject3 = results.getString("subject3");
            int marks3 = results.getInt("marks3");
            org.wiley.sms.bean.Student student = new org.wiley.sms.bean.Student(id, name, subject1, marks1, subject2, marks2, subject3, marks3);
            students.put(student.getId(), student);
        }
        return students;
    }

    @Override
    public Student getStudentById(long id) throws ClassNotFoundException, SQLException, StudentNotFoundException {
        java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
        String sql = "SELECT * FROM Student WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.setLong(1, id);
        java.sql.ResultSet result = statement.executeQuery();
        org.wiley.sms.bean.Student student;
        if(result.next()) {
            String name = result.getString("name");
            String subject1 = result.getString("subject1");
            int marks1 = result.getInt("marks1");
            String subject2 = result.getString("subject2");
            int marks2 = result.getInt("marks2");
            String subject3 = result.getString("subject3");
            int marks3 = result.getInt("marks3");
            student = new org.wiley.sms.bean.Student(id, name, subject1, marks1, subject2, marks2, subject3, marks3);
        } else {
            throw new org.wiley.sms.exception.StudentNotFoundException("Student with id " + id + " not found");
        }
        connection.close();
        return student;
    }

    @Override
    public Student updateStudent(long id, Student student) throws ClassNotFoundException, SQLException, StudentNotFoundException {
        getStudentById(id);
        java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
        String sql = "UPDATE Student SET name = ?, subject1 = ?, marks1 = ?, subject2 = ?, marks2 = ?, subject3 = ?, marks3 = ? WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, student.getName());
        statement.setString(2, student.getSubject1());
        statement.setInt(3, student.getMarks1());
        statement.setString(4, student.getSubject2());
        statement.setInt(5, student.getMarks2());
        statement.setString(6, student.getSubject3());
        statement.setInt(7, student.getMarks3());
        statement.setLong(8, id);
        statement.execute();
        if(!connection.getAutoCommit()) {
            connection.commit();
        }
        connection.close();
        org.wiley.sms.bean.Student updatedStudent = getStudentById(id);
        return updatedStudent;
    }

    @Override
    public boolean deleteStudent(long id) throws ClassNotFoundException, SQLException, StudentNotFoundException {
        getStudentById(id);
        java.sql.Connection connection = org.wiley.sms.util.DBUtil.getConnection();
        String sql = "DELETE FROM Student WHERE id = ?";
        java.sql.PreparedStatement statement = connection.prepareStatement(sql);
        statement.setLong(1, id);
        statement.execute();
        if(!connection.getAutoCommit()) {
            connection.commit();
        }
        connection.close();
        return true;
    }
}
