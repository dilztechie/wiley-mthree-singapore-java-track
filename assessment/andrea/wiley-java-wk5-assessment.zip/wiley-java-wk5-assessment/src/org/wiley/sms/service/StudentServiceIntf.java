package org.wiley.sms.service;

import org.wiley.sms.exception.StudentNotFoundException;

public interface StudentServiceIntf {
    public long addStudent(String name, String subject1, int marks1, String subject2, int marks2, String subject3, int marks3)
        throws ClassNotFoundException, java.sql.SQLException;

    public java.util.Map<Long, org.wiley.sms.bean.Student> getAllStudents()
        throws ClassNotFoundException, java.sql.SQLException;

    public org.wiley.sms.bean.Student getStudentById(long id)
            throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.StudentNotFoundException;

    public org.wiley.sms.bean.Student updateStudent(long id, org.wiley.sms.bean.Student student)
        throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.StudentNotFoundException;

    public boolean deleteStudent(long id)
        throws ClassNotFoundException, java.sql.SQLException, org.wiley.sms.exception.StudentNotFoundException;
}
