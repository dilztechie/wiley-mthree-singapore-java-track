public class StudentManagementSystem {
    static java.util.Scanner in = new java.util.Scanner(System.in);

    static org.wiley.sms.service.StudentServiceIntf studentService = new org.wiley.sms.service.StudentServiceImpl();

    public static void main(String[] args) {
        int choice = 0;
        do {
            sop("\n");
            try {
                menu();
                choice = in.nextInt();
                switch(choice) {
                    case 1: addStudents(); break;
                    case 2: getAllStudents(); break;
                    case 3: getStudentById(); break;
                    case 4: updateStudent(); break;
                    case 5: deleteStudent(); break;
                    case 0: break;
                    default: throw new org.wiley.sms.exception.InvalidChoiceException("Invalid choice! Try 1-5, 0: exit");
                }
            } catch(org.wiley.sms.exception.InvalidChoiceException ice) {
                System.err.println(ice.getMessage());
            }
            sop("\n");
        } while(choice!=0);
    }

    static void menu() {
        sop("Student Management System\n");
        sop("--------------------------\n");
        sop("1. Add students\n");
        sop("2. Get All students\n");
        sop("3. Get student By ID\n");
        sop("4. Update student\n");
        sop("5. Delete student\n");
        sop("0. Exit\n");
        sop("Choice? ");
    }

    static void sop(String text) {
        System.out.print(text);
    }

    static void addStudents() {
        try {
            sop("name? ");
            if(in.hasNextLine()) {
                in.nextLine();
            }
            String name = in.nextLine();
            sop("subject 1? ");
            if(in.hasNextLine()) {
                in.nextLine();
            }
            String subject1 = in.nextLine();
            sop("marks 1? ");
            int marks1 = in.nextInt();
            sop("subject 2? ");
            if(in.hasNextLine()) {
                in.nextLine();
            }
            String subject2 = in.nextLine();
            sop("marks 2? ");
            int marks2 = in.nextInt();
            sop("subject 3? ");
            if(in.hasNextLine()) {
                in.nextLine();
            }
            String subject3 = in.nextLine();
            sop("marks 3? ");
            int marks3 = in.nextInt();
            sop("Student added with id " + studentService.addStudent(name, subject1, marks1, subject2, marks2, subject3, marks3) + "\n");
        } catch(ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch(java.sql.SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    static void getAllStudents() {
        try {
            java.util.Map<Long, org.wiley.sms.bean.Student> students = studentService.getAllStudents();
            java.util.Set<Long> ids = students.keySet();
            if(ids.size() == 0 || ids == null) {
                throw new org.wiley.sms.exception.NoStudentsExistException("No students in the database!");
            }
            for(long id : ids) {
                sop(students.get(id) + "\n");
            }
        } catch(org.wiley.sms.exception.NoStudentsExistException nsee) {
            System.err.println(nsee.getMessage());
        } catch(ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch(java.sql.SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    static void getStudentById() {
        try {
            sop("id? ");
            long id = in.nextLong();
            sop(studentService.getStudentById(id) + "\n");
        } catch(ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch(java.sql.SQLException sqle) {
            sqle.printStackTrace();
        } catch(org.wiley.sms.exception.StudentNotFoundException snfe) {
            System.err.println(snfe.getMessage());
        }
    }

    static void updateStudent() {
        try {
            sop("id? ");
            long id = in.nextLong();
            sop("name? ");
            if(in.hasNextLine()) {
                in.nextLine();
            }
            String name = in.nextLine();
            sop("subject 1? ");
            if(in.hasNextLine()) {
                in.nextLine();
            }
            String subject1 = in.nextLine();
            sop("marks 1? ");
            int marks1 = in.nextInt();
            sop("subject 2? ");
            if(in.hasNextLine()) {
                in.nextLine();
            }
            String subject2 = in.nextLine();
            sop("marks 2? ");
            int marks2 = in.nextInt();
            sop("subject 3? ");
            if(in.hasNextLine()) {
                in.nextLine();
            }
            String subject3 = in.nextLine();
            sop("marks 3? ");
            int marks3 = in.nextInt();
            org.wiley.sms.bean.Student student = new org.wiley.sms.bean.Student(id, name, subject1, marks1, subject2, marks2, subject3, marks3);
            sop("Updated student: " + studentService.updateStudent(id, student) + "\n");
        } catch(ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch(java.sql.SQLException sqle) {
            sqle.printStackTrace();
        } catch(org.wiley.sms.exception.StudentNotFoundException snfe) {
            System.err.println(snfe.getMessage());
        }
    }

    static void deleteStudent() {
        try {
            sop("id? ");
            long id = in.nextLong();
            if(studentService.deleteStudent(id)) {
                sop("student with id " + id + " deleted\n");
            }
        } catch(ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch(java.sql.SQLException sqle) {
            sqle.printStackTrace();
        } catch(org.wiley.sms.exception.StudentNotFoundException snfe) {
            System.err.println(snfe.getMessage());
        }
    }
}

